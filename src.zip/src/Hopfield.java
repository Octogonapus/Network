public class Hopfield {
    //Each neuron is tied to each other neuron
    //Used for pattern recognition
    public static void main(String[] args) {
        //One input per neuron
        int input1, input2, input3, input4;
        input1 = 0;
        input2 = 0;
        input3 = 0;
        input4 = 0;
    }
}
